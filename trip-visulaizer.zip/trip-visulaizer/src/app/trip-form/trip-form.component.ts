import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { TripService } from '../shared/trip.service';

@Component({
  selector: 'app-trip-form',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './trip-form.component.html',
  styleUrls: ['./trip-form.component.css'],
})
export class TripFormComponent {
  startPoint = '';
  endPoint = '';

  constructor(private tripService: TripService) {}

  addTrip() {
    if (this.startPoint && this.endPoint) {
      this.tripService.addTrip(this.startPoint, this.endPoint);
      this.startPoint = '';
      this.endPoint = '';
    }
  }
}
