import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TripFormComponent } from './trip-form/trip-form.component';
import { TripGraphComponent } from './trip-graph/trip-graph.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, TripFormComponent, TripGraphComponent],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {}
