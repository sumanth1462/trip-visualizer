import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export interface Trip {
  start: string;
  end: string;
  value: number;
}

@Injectable({
  providedIn: 'root',
})
export class TripService {
  private tripsSubject = new BehaviorSubject<Trip[]>([]);
  trips$ = this.tripsSubject.asObservable();

  private lastTripEnd: string | null = null;

  /**
   * Adds a new trip to the trip visualization system.
   *
   * This method processes the trip locations, detects repeat trips, and updates
   * the trip state accordingly. It performs the following operations:
   * 1. Normalizes location names to 3-letter uppercase codes
   * 2. Identifies repeat trips (consecutive identical routes)
   * 3. Marks trips with a value indicating their type (normal or repeated)
   * 4. Updates the application state with the new trip information
   *
   * @param {string} start - The full name of the starting location (e.g. "Bangalore")
   * @param {string} end - The full name of the destination location (e.g. "Chennai")
   * @returns {void}
   *
   * @example
   * // Add first trip
   * addTrip("Bangalore", "Chennai"); // Creates BAN → CHE (value: 1)
   *
   * @example
   * // Add repeat trip
   * addTrip("Chennai", "Delhi");     // Creates CHE → DEL (value: 1)
   * addTrip("Chennai", "Delhi");     // Updates both to value: 2
   */
  addTrip(start: string, end: string) {
    const currentTrips = this.tripsSubject.value;
    const isRepeat =
      currentTrips.length > 0 &&
      currentTrips[currentTrips.length - 1].start ===
        start.substring(0, 3).toUpperCase() &&
      currentTrips[currentTrips.length - 1].end ===
        end.substring(0, 3).toUpperCase();

    const newTrip: Trip = {
      start: start.substring(0, 3).toUpperCase(),
      end: end.substring(0, 3).toUpperCase(),
      value: isRepeat ? 2 : 1,
    };

    if (isRepeat) {
      currentTrips[currentTrips.length - 1].value = 2;
    }

    this.tripsSubject.next([...currentTrips, newTrip]);
    this.lastTripEnd = end;
  }

  getTripDataForChart() {
    const trips = this.tripsSubject.value;
    const seriesData: any[] = [];

    seriesData.push({
      name: 'End Points',
      type: 'line',
      data: trips.map((trip, index) => ({
        value: trip.value,
        name: `${trip.start} - ${trip.end}`,
      })),
      lineStyle: { type: 'solid', width: 2, join: 'square' },
      symbol: 'circle',
      symbolSize: 10,
      smooth: true,
      label: {
        show: true,
        formatter: '{b}', //display start and end points name(eg: HYD - DEL)
      },
    });

    return seriesData;
  }

  private getLineColor(lineType: string): string {
    switch (lineType) {
      case 'dashed':
        return '#FF5722';
      case 'dotted':
        return '#9C27B0';
      default:
        return '#4CAF50';
    }
  }
}
