import type { EChartsType, EChartsOption } from 'echarts';
import * as echarts from 'echarts';

export function initChart(container: HTMLElement, options: EChartsOption) {
  const chart: EChartsType = echarts.init(container);
  chart.setOption({...options});

  const resizeObserver = new ResizeObserver(() => {
    chart.resize();
  });

  resizeObserver.observe(container);

  return {
    update(newOptions: EChartsOption) {
      chart.setOption({...newOptions}, true);
    },
    destroy() {
      resizeObserver.disconnect();
      chart.dispose();
    },
  };
}