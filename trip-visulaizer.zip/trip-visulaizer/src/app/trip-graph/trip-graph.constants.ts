export const options: echarts.EChartsOption = {
  title: {
    text: 'Trip Visualization',
    left: 'center',
  },
  tooltip: {
    trigger: 'item',
    formatter: (params: any) => {
      return `${params.data.name}`;
    },
  },
  xAxis: {
    type: 'category',
    axisLine: { show: false },
    axisLabel: { show: false },
    splitLine: { show: false },
    axisTick: {
      show: true,
    },
  },
  yAxis: {
    type: 'value',
    axisLine: { show: false },
    axisLabel: { show: false },
    splitLine: { show: false },
  },
  series: [],
  animationEasing: 'elasticOut',
};
