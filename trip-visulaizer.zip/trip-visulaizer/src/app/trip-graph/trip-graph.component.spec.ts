import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TripGraphComponent } from './trip-graph.component';

describe('TripGraphComponent', () => {
  let component: TripGraphComponent;
  let fixture: ComponentFixture<TripGraphComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TripGraphComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TripGraphComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
