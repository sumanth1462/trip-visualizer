import {
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
  AfterViewInit,
} from '@angular/core';
import { TripService } from '../shared/trip.service';
import { CommonModule } from '@angular/common';
import { initChart } from '../shared/echart.wrapper';
import { options } from './trip-graph.constants';

@Component({
  selector: 'app-trip-graph',
  imports: [CommonModule],
  templateUrl: './trip-graph.component.html',
  styleUrl: './trip-graph.component.css',
  standalone: true,
})
export class TripGraphComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild('chartContainer') chartContainer!: ElementRef;
  private chart: any;

  constructor(private tripService: TripService) {}

  ngOnInit() {
    this.tripService.trips$.subscribe(() => {
      this.updateChart();
    });
  }

  ngAfterViewInit() {
    this.updateChart();
  }

  ngOnDestroy() {
    if (this.chart) {
      this.chart.destroy();
    }
  }

  private updateChart() {
    // Get current trip data from service
    const seriesData = this.tripService.getTripDataForChart();
    const chartOptions = options;

    // Prepare chart options with updated series data
    chartOptions.series = seriesData.map((series: any, index: number) => ({
      ...series,
    }));

    if (!this.chart && this.chartContainer?.nativeElement) {
      this.chart = initChart(this.chartContainer.nativeElement, options);
    } else if (this.chart) {
      this.chart.update(options);
    }
  }
}
